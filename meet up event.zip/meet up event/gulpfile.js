var gulp = require('gulp');
var start = require('browser-sync');
var sass = require('gulp-sass');
var eslint = require('gulp-eslint');
var concat = require('gulp-concat');
var autoprefixer = require('gulp-autoprefixer');
var cleanCSS = require('gulp-clean-css');

gulp.task('default',['dist'],function(){

});

gulp.task('dist',['html','style','script','concat','image','serve'])

gulp.task('serve',function() {
	start.init({
		server: {
			baseDir: 'dist'
		}
	});
});

gulp.task('style',function(){
	gulp.src('style/sass/**/*.scss')
	.pipe(sass.sync().on('error', sass.logError))
	.pipe(autoprefixer({
            browsers: ['last 2 versions'],
            cascade: false
        }))
    .pipe(cleanCSS({compatibility: 'ie8'}))
    .pipe(gulp.dest('dist/style'));
});

gulp.task('concat',function(){
	gulp.src('javascript/**/*.js')
	.pipe(concat('app.js'))
	.pipe(gulp.dest('dist/script'))
});


gulp.task('script',function(){
	gulp.src('javascript/**/*.js')
	.pipe(gulp.dest('dist/script'))
});

gulp.task('html', function(){
	
	gulp.src('app/**/*.html')
	.pipe(gulp.dest('./dist'))
	});

gulp.task('image', function(){
	gulp.src('image/**/*')
	.pipe(gulp.dest('dist/image'));
});

gulp.task('lint', function(){
	gulp.src(['javascript/**/*.js'])
	.pipe(eslint())
	.pipe(eslint.format())
	.pipe(eslint.failOnError);
});


gulp.task('watch',['serve'],function(){
	gulp.watch('app/index.html',start.reload);
	gulp.watch('app/create.html',start.reload);
	gulp.watch('app/view.html',start.reload);
	gulp.watch('app/register.html',start.reload);
})