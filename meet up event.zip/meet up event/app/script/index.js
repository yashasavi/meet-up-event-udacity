function w3_open() {
	document.getElementById("mySidenav").style.width = "50%";
    document.getElementById("mySidenav").style.display = "block";
}
function w3_close() {
    document.getElementById("mySidenav").style.display = "none";
}