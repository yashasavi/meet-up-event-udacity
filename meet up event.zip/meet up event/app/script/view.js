var gc=localStorage.getItem("event_guest");
var mc=localStorage.getItem("event_message");
document.getElementById("invite_text").rows[0].cells[1].innerHTML=localStorage.getItem("event_name");
document.getElementById("invite_text").rows[1].cells[1].innerHTML=localStorage.getItem("event_type");
document.getElementById("invite_text").rows[2].cells[1].innerHTML=localStorage.getItem("event_start");
document.getElementById("invite_text").rows[3].cells[1].innerHTML=localStorage.getItem("event_end");
document.getElementById("invite_text").rows[4].cells[1].innerHTML=localStorage.getItem("host_name");
document.getElementById("invite_text").rows[5].cells[1].innerHTML=localStorage.getItem("event_location");
	if (gc=="void")
	{
		$(".guest").hide();
		
	}
	else
	{
		document.getElementById("invite_text").rows[6].cells[1].innerHTML=localStorage.getItem("event_guest"); 
	}
	if (mc=="void")
	{
		$(".message").hide();
	}
	else
	{
		document.getElementById("invite_text").rows[7].cells[1].innerHTML=localStorage.getItem("event_message");
	}

function w3_open() {
	document.getElementById("mySidenav").style.width = "50%";
    document.getElementById("mySidenav").style.display = "block";
}
function w3_close() {
    document.getElementById("mySidenav").style.display = "none";
} 
