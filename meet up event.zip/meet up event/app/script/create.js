var btn_on=2;
var c1=0;
var c2=0;
var c3=0;
var c4=0;
var c5=0;
var c6=0;
var c7=0;
var k1=0;
var k2=0;
var k3=0;
var k4=0;
var k5=0;
var k6=0;
var k7=0;

document.getElementById("button").disabled = true;

$(document).ready(function(){
    $(".name_check").hide();
});
function w3_open() {
	document.getElementById("mySidenav").style.width = "50%";
    document.getElementById("mySidenav").style.display = "block";
}
function w3_close() {
    document.getElementById("mySidenav").style.display = "none";
} 


function check_input() {
	if (document.getElementById("eventname").value=="")
	{
		$(".name_check").show();
		c1=0;
	}
	else
	{
		$(".name_check").hide();
		c1=1;
		k1=k1+1;
	}

	if(c1==0)
		{
			btn_on=btn_on+0;
		}
		else if (btn_on==7)
		{
			document.getElementById("button").disabled = false;
		}
		else if (c1==1 && k1==1)
		{
			btn_on=btn_on+1;
		}
}



function getlocation()
{
	if (navigator.geolocation){
	  navigator.geolocation.getCurrentPosition(showPosition);
	}

	function showPosition(position){ 
	    location.latitude=position.coords.latitude;
	    location.longitude=position.coords.longitude;
	    var geocoder = new google.maps.Geocoder();
	    var latLng = new google.maps.LatLng(location.latitude, location.longitude);
	 
	    geocoder.geocode({'latLng': latLng}, function(results, status) {
		if (status == google.maps.GeocoderStatus.OK){
	        document.getElementById("location").value=results[0].formatted_address;
	    }
	    else {
	    	console.log("reverse geocode of "+latLng+ " failed ("+status+")");
	    }
	    });      
	}	


}



function generateinvite() {

var ename= document.getElementById("eventname").value;
document.getElementById("invite_text").rows[0].cells[1].innerHTML=ename;
var etype= document.getElementById("eventtype").value;
document.getElementById("invite_text").rows[1].cells[1].innerHTML=etype;
var estart= document.getElementById("eventstart").value;
document.getElementById("invite_text").rows[2].cells[1].innerHTML=estart;
var eend= document.getElementById("eventend").value;
document.getElementById("invite_text").rows[3].cells[1].innerHTML=eend;
var hname= document.getElementById("hostname").value;
document.getElementById("invite_text").rows[4].cells[1].innerHTML=hname;
var elocation= document.getElementById("location").value;
document.getElementById("invite_text").rows[5].cells[1].innerHTML=elocation;
var eguest= document.getElementById("guestlist").value;
document.getElementById("invite_text").rows[6].cells[1].innerHTML=eguest;
var emessage= document.getElementById("message").value;
document.getElementById("invite_text").rows[7].cells[1].innerHTML=emessage;

if (typeof(Storage) !== "undefined") {
    localStorage.setItem("event_name", ename);
	localStorage.setItem("event_type", etype);
	localStorage.setItem("event_start", estart);
	localStorage.setItem("event_end", eend);
	localStorage.setItem("host_name", hname);
	localStorage.setItem("event_location", elocation);
	localStorage.setItem("event_guest", eguest);
	localStorage.setItem("event_message", emessage);
    
	}

}

function guest_show() 
{
    $(".guest").show();
}
function guest_hide() 
{
    $(".guest").hide();
}

function message_show() 
{
    $(".message").show();
}
function message_hide() 
{
    $(".message").hide();
}

function check_time1() {
	var start = new Date(document.getElementById("eventstart").value);
	var today = new Date();
	if (start<today)
	{
		document.getElementById("check_date").innerHTML="Please check the Dates<br>*Start Date connot be in Past.";
		c2=0;
	}
	else
	{
		document.getElementById("check_date").innerHTML="";
		c2=1;
		k2=k2+1;
	}

	if(c2==0)
		{
			btn_on=btn_on+0;
		}
		else if (btn_on==7)
		{
			document.getElementById("button").disabled = false;

		}
		else if (c2==1 && k2==1) 
		{
			btn_on=btn_on+1;
		}
}

function check_time2() {
	var start = new Date(document.getElementById("eventstart").value);
	var end = new Date(document.getElementById("eventend").value);
	var today = new Date();
	if (end<start)
	{	
		document.getElementById("check_date").innerHTML="*End date cannot be less than Start Date.";
		c3=0;
	}
	else
	{
		document.getElementById("check_date").innerHTML="";	
		c3=1;
		k3=k3+1;
	}

	if(c3==0)
		{
			btn_on=btn_on+0;
		}
		else if (btn_on==7)
		{
			document.getElementById("button").disabled = false;

		}
		else if (c3==1 && k3==1)
		{
			btn_on=btn_on+1;
		}	

}

function type_check() {
if (document.getElementById("eventtype").value=="")
	{
		document.getElementById("type_check").innerHTML="Please Enter Event Type";	
		c4=0;
	}
	else
	{
		document.getElementById("type_check").innerHTML="";
		c4=0;
		k4=k4+1;
	}

	if(c4==0)
		{
			btn_on=btn_on+0;
		}
		else if (btn_on==7)
		{
			document.getElementById("button").disabled = false;

		}
		else if (c4==1 && k4==1)
		{
			btn_on=btn_on+1;
		}
}

function host_check() {
	if (document.getElementById("hostname").value=="")
	{
		document.getElementById("host_check").innerHTML="Please Enter Host Name";	
		c5=0;
	}
	else
	{
		document.getElementById("host_check").innerHTML="";
		c5=1;
		k5=k5+1;
	}	

	if(c5==0)
		{
			btn_on=btn_on+0;
		}
		else if (btn_on==7)
		{
			document.getElementById("button").disabled = false;

		}
		else if (c5==1 && k5==1)
		{
			btn_on=btn_on+1;
		}
}

function location_check() {
	if (document.getElementById("location").value=="")
	{
		document.getElementById("location_check").innerHTML="Please Enter a location";	
		c6=0;
	}
	else
	{
		document.getElementById("location_check").innerHTML="";
		c6=1;
		k6=k6+1;
	}

	if(c6==0)
		{
			btn_on=btn_on+0;
		}
		else if (btn_on==7)
		{
			document.getElementById("button").disabled = false;

		}
		else if (c6==1 && k6==1)
		{
			btn_on=btn_on+1;
		}
}

function guest_check() {
	
	if (document.getElementById("guestlist").value=="")
	{
		document.getElementById("guest_check").innerHTML="Please Enter Guests";	
		c7=0;
	}
	else
	{
		document.getElementById("guest_check").innerHTML="";
		c7=1;
		k7=k7+1;
	}

	if(c7==0)
		{
			btn_on=btn_on+0;
		}
		else if (btn_on==7)
		{
			document.getElementById("button").disabled = false;

		}
		else if (c7==1 && k7==1)
		{
			btn_on=btn_on+1;
		}
}

