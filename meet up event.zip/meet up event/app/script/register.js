$(document).ready(function(){
    $(".email_check").hide();
     $(".name_check").hide();
});
var barvalue=0;
var count=1;
var count2=1;
var count3=1;
function demo() {
	var n=0;
pass = document.getElementById("password").value;

	
		if (pass.length<8)
		{
			document.getElementById("pass1").style.color = "red";
		}
		else if (pass.length>100)
		{
			document.getElementById("pass1").style.color = "red";
		}
		else 
		{
			document.getElementById("pass1").style.color = "green";
			n=n+1;
		}
		
		if (pass.match(/[\!\@\#\$\%\^\&\*]/g))
		{
			document.getElementById("pass2").style.color = "green";
			n=n+1;
		}
		else
		{
			document.getElementById("pass2").style.color = "red";
		}
		if (pass.match(/\d/g))
		{
			document.getElementById("pass3").style.color = "green";
			n=n+1;
		}
		else
		{
			document.getElementById("pass3").style.color = "red";
		}
		if (pass.match(/[a-z]/g))
		{
			document.getElementById("pass4").style.color = "green";
			n=n+1;
		}
		else
		{
			document.getElementById("pass4").style.color = "red";
		}
		if (pass.match(/[A-Z]/g))
		{
			document.getElementById("pass5").style.color = "green";
			n=n+1;
		}
		else
		{
			document.getElementById("pass5").style.color = "red";
		}
		
	if (n==5 && count3<2)
	{	
		count3=count3+1;
		barvalue+=40;
		document.getElementById("bar").style.width = barvalue + "%";
	    document.getElementById("barno").innerHTML = barvalue + "%";
	}
		
	

}

function w3_open() {
	document.getElementById("mySidenav").style.width = "50%";
    document.getElementById("mySidenav").style.display = "block";
}
function w3_close() {
    document.getElementById("mySidenav").style.display = "none";
} 

function progress1() {
	name = document.getElementById("name").value;
	if (name.length>0 && count<2)
	{
		count=count+1;
		barvalue+=30;
		document.getElementById("bar").style.width = barvalue + "%";
	    document.getElementById("barno").innerHTML = barvalue + "%";
	    $(".name_check").hide();
	}
	else if(name!="") 
	{
		$(".name_check").hide();
	}
	else
		{
			$(".name_check").show();	
		}
	
}
function progress2() {
	email = document.getElementById("email").value;
	
	if (email.length>0 && email.match(/[\@\.]/g) && count2<2)
	{
		count2=count2+1;
		barvalue+=30;
		document.getElementById("bar").style.width = barvalue + "%";
	    document.getElementById("barno").innerHTML = barvalue + "%";
	    $(".email_check").hide();
	}
	else if(email!="") 
	{
		$(".name_check").hide();
	}
	else
	{
		$(".email_check").show();
	}
	
}

